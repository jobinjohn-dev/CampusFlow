"""Recursive-descent parser for the CampusFlow Phase 2 grammar."""

from .ast import (
    AssignStatement,
    CancelStatement,
    Condition,
    ConditionalStatement,
    EventStatement,
    Program,
    ReserveStatement,
    SourceLocation,
    Statement,
)
from .model import ParseResult, SyntaxErrorInfo, Token


class _ParseFailure(Exception):
    def __init__(self, error: SyntaxErrorInfo):
        super().__init__(error.message)
        self.error = error


class Parser:
    """Parse a CampusFlow token stream and recover at statement boundaries."""

    def __init__(self, tokens: tuple[Token, ...]):
        self.tokens = tokens
        self.index = 0
        self.errors: list[SyntaxErrorInfo] = []

    def parse(self) -> ParseResult:
        statements: list[Statement] = []
        while not self._at_end():
            try:
                statements.append(self._parse_statement())
            except _ParseFailure as failure:
                self.errors.append(failure.error)
                self._synchronize()
        return ParseResult(Program(tuple(statements)), tuple(self.errors))

    def _parse_statement(self) -> Statement:
        token = self._current()
        if token.kind != "KEYWORD":
            self._fail("Expected a statement keyword", token)

        keyword = token.lexeme.upper()
        if keyword == "EVENT":
            return self._parse_event()
        if keyword == "RESERVE":
            return self._parse_reserve()
        if keyword == "ASSIGN":
            return self._parse_assign()
        if keyword == "IF":
            return self._parse_conditional()
        if keyword == "CANCEL":
            return self._parse_cancel()
        self._fail("Expected a statement keyword", token)

    def _parse_event(self) -> EventStatement:
        start = self._expect_keyword("EVENT")
        name = self._expect_kind("IDENTIFIER", "event identifier")
        self._expect_keyword("ON")
        date = self._expect_kind("DATE", "date")
        self._expect_keyword("AT")
        start_time = self._expect_kind("TIME", "start time")
        self._expect_keyword("TO")
        end_time = self._expect_kind("TIME", "end time")
        self._expect_semicolon()
        return EventStatement(
            name.lexeme,
            date.lexeme,
            start_time.lexeme,
            end_time.lexeme,
            SourceLocation(start.line, start.column),
        )

    def _parse_reserve(self) -> ReserveStatement:
        start = self._expect_keyword("RESERVE")
        resource = self._expect_kind("IDENTIFIER", "resource identifier")
        self._expect_keyword("FOR")
        event = self._expect_kind("IDENTIFIER", "event identifier")
        self._expect_keyword("CAPACITY")
        capacity = self._expect_kind("NUMBER", "capacity number")
        self._expect_semicolon()
        return ReserveStatement(
            resource.lexeme,
            event.lexeme,
            int(capacity.lexeme),
            SourceLocation(start.line, start.column),
        )

    def _parse_assign(self) -> AssignStatement:
        start = self._expect_keyword("ASSIGN")
        equipment = self._expect_kind("IDENTIFIER", "equipment identifier")
        self._expect_keyword("TO")
        event = self._expect_kind("IDENTIFIER", "event identifier")
        self._expect_semicolon()
        return AssignStatement(
            equipment.lexeme,
            event.lexeme,
            SourceLocation(start.line, start.column),
        )

    def _parse_conditional(self) -> ConditionalStatement:
        start = self._expect_keyword("IF")
        left = self._current()
        if not (
            left.kind == "IDENTIFIER"
            or (left.kind == "KEYWORD" and left.lexeme.upper() == "CAPACITY")
        ):
            self._fail("Expected condition identifier", left)
        self._advance()
        operator = self._expect_kind("OPERATOR", "comparison operator")
        right = self._expect_kind("NUMBER", "comparison number")
        self._expect_keyword("THEN")
        action = self._parse_reserve()
        return ConditionalStatement(
            Condition(
                left.lexeme,
                operator.lexeme,
                int(right.lexeme),
                SourceLocation(left.line, left.column),
            ),
            action,
            SourceLocation(start.line, start.column),
        )

    def _parse_cancel(self) -> CancelStatement:
        start = self._expect_keyword("CANCEL")
        event = self._expect_kind("IDENTIFIER", "event identifier")
        self._expect_semicolon()
        return CancelStatement(event.lexeme, SourceLocation(start.line, start.column))

    def _expect_keyword(self, keyword: str) -> Token:
        token = self._current()
        if token.kind != "KEYWORD" or token.lexeme.upper() != keyword:
            self._fail(f"Expected keyword {keyword}", token)
        return self._advance()

    def _expect_kind(self, kind: str, description: str) -> Token:
        token = self._current()
        if token.kind != kind:
            self._fail(f"Expected {description}", token)
        return self._advance()

    def _expect_semicolon(self) -> Token:
        token = self._current()
        if token.kind != "SEMICOLON":
            self._fail("Expected ';'", token)
        return self._advance()

    def _synchronize(self) -> None:
        while not self._at_end() and self._current().kind != "SEMICOLON":
            self._advance()
        if self._current().kind == "SEMICOLON":
            self._advance()

    def _fail(self, message: str, token: Token):
        raise _ParseFailure(SyntaxErrorInfo(message, token.line, token.column))

    def _at_end(self) -> bool:
        return self._current().kind == "EOF"

    def _current(self) -> Token:
        return self.tokens[min(self.index, len(self.tokens) - 1)]

    def _advance(self) -> Token:
        token = self._current()
        if token.kind != "EOF":
            self.index += 1
        return token
