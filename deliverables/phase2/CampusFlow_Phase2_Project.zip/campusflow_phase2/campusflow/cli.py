"""Command-line interface for the CampusFlow Phase 2 compiler front end."""

import argparse
from pathlib import Path

from .ast import format_ast
from .compiler import compile_source
from .ir import format_ir
from .lexer import Lexer
from .symbols import format_symbol_table


def format_result(source_name: str, source: str) -> tuple[str, int]:
    """Return formatted lexer output and its process exit code."""
    result = Lexer(source).scan()
    lines = [
        f"CampusFlow lexical analysis: {source_name}",
        "",
        f"{'LINE:COL':<10} {'TOKEN':<18} LEXEME",
        f"{'-' * 8:<10} {'-' * 16:<18} {'-' * 24}",
    ]
    for token in result.tokens:
        display_lexeme = token.lexeme if token.kind != "EOF" else "<end>"
        lines.append(
            f"{token.line}:{token.column:<8} {token.kind:<18} {display_lexeme}"
        )

    lines.append("")
    if result.errors:
        lines.append("LEXICAL ERRORS")
        lines.append("--------------")
        for error in result.errors:
            lines.append(f"{error.line}:{error.column}  {error.message}")
        lines.append(f"Total lexical errors: {len(result.errors)}")
        return "\n".join(lines), 1

    lines.append("No lexical errors.")
    lines.append(f"Total tokens: {len(result.tokens)}")
    return "\n".join(lines), 0


def _section(title: str, body: str) -> str:
    return f"{title}\n{'=' * len(title)}\n{body}"


def format_compilation(source_name: str, source: str, stage: str) -> tuple[str, int]:
    """Compile source and format one selected stage or the complete pipeline."""
    if stage == "tokens":
        token_output, exit_code = format_result(source_name, source)
        return _section("TOKENS", token_output), exit_code

    result = compile_source(source)
    if result.status == "lexical_error":
        token_output, _ = format_result(source_name, source)
        return _section("TOKENS", token_output), 1

    if result.status == "syntax_error":
        assert result.parse is not None
        lines = [
            f"{error.line}:{error.column}  {error.message}"
            for error in result.parse.errors
        ]
        lines.append(f"Total syntax errors: {len(result.parse.errors)}")
        return _section("SYNTAX ERRORS", "\n".join(lines)), 2

    if result.status == "semantic_error":
        assert result.semantic is not None
        lines = [
            f"{error.line}:{error.column}  {error.message}"
            for error in result.semantic.errors
        ]
        lines.append(f"Total semantic errors: {len(result.semantic.errors)}")
        return _section("SEMANTIC ERRORS", "\n".join(lines)), 3

    assert result.parse is not None
    assert result.semantic is not None
    sections: list[str] = []
    if stage == "all":
        token_output, _ = format_result(source_name, source)
        sections.append(_section("TOKENS", token_output))
    if stage in {"all", "ast"}:
        sections.append(_section("ABSTRACT SYNTAX TREE", format_ast(result.parse.program)))
    if stage in {"all", "symbols"}:
        sections.append(
            _section("SYMBOL TABLE", format_symbol_table(result.semantic.symbols))
        )
    if stage in {"all", "ir"}:
        sections.append(_section("INTERMEDIATE CODE", format_ir(result.ir)))
    sections.append("Compilation completed successfully.")
    return "\n\n".join(sections), 0


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        description="Compile a CampusFlow DSL source file through the Phase 2 front end."
    )
    parser.add_argument(
        "--stage",
        choices=("tokens", "ast", "symbols", "ir", "all"),
        default="all",
        help="Output to display (default: all)",
    )
    parser.add_argument("source_file", type=Path, help="Path to a .cflow file")
    arguments = parser.parse_args(argv)

    try:
        source = arguments.source_file.read_text(encoding="utf-8")
    except OSError as error:
        parser.error(str(error))

    output, exit_code = format_compilation(
        str(arguments.source_file), source, arguments.stage
    )
    print(output)
    return exit_code
