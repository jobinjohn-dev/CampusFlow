"""Quadruple intermediate representation for CampusFlow Phase 2."""

from dataclasses import dataclass

from .ast import (
    AssignStatement,
    CancelStatement,
    ConditionalStatement,
    EventStatement,
    Program,
    ReserveStatement,
)


@dataclass(frozen=True)
class Quadruple:
    operation: str
    argument1: str
    argument2: str
    result: str


class IRGenerator:
    def __init__(self):
        self._next_label = 1

    def generate(self, program: Program) -> tuple[Quadruple, ...]:
        code: list[Quadruple] = []
        for statement in program.statements:
            if isinstance(statement, EventStatement):
                code.append(
                    Quadruple(
                        "EVENT",
                        statement.date,
                        f"{statement.start_time}..{statement.end_time}",
                        statement.name,
                    )
                )
            elif isinstance(statement, ReserveStatement):
                code.append(self._reserve(statement))
            elif isinstance(statement, AssignStatement):
                code.append(Quadruple("ASSIGN", statement.equipment, "-", statement.event))
            elif isinstance(statement, ConditionalStatement):
                label = self._new_label()
                condition = statement.condition
                code.append(
                    Quadruple(
                        "IF_FALSE",
                        f"{condition.left} {condition.operator} {condition.right}",
                        "-",
                        label,
                    )
                )
                code.append(self._reserve(statement.action))
                code.append(Quadruple("LABEL", "-", "-", label))
            elif isinstance(statement, CancelStatement):
                code.append(Quadruple("CANCEL", statement.event, "-", "-"))
        return tuple(code)

    @staticmethod
    def _reserve(statement: ReserveStatement) -> Quadruple:
        return Quadruple(
            "RESERVE", statement.resource, str(statement.capacity), statement.event
        )

    def _new_label(self) -> str:
        label = f"L{self._next_label}"
        self._next_label += 1
        return label


def format_ir(code: tuple[Quadruple, ...]) -> str:
    lines = [
        f"{'#':<4} {'OP':<12} {'ARG1':<20} {'ARG2':<20} RESULT",
        "---- ------------ -------------------- -------------------- --------------------",
    ]
    if not code:
        lines.append("<empty>")
        return "\n".join(lines)
    for index, item in enumerate(code, 1):
        lines.append(
            f"{index:<4} {item.operation:<12} {item.argument1:<20} "
            f"{item.argument2:<20} {item.result}"
        )
    return "\n".join(lines)
