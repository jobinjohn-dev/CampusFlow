"""Immutable result records produced by the CampusFlow lexer."""

from dataclasses import dataclass

from .ast import Program


@dataclass(frozen=True)
class Token:
    """A classified lexeme and its one-based source position."""

    kind: str
    lexeme: str
    line: int
    column: int


@dataclass(frozen=True)
class LexicalError:
    """A recoverable lexical error and its one-based source position."""

    message: str
    line: int
    column: int


@dataclass(frozen=True)
class ScanResult:
    """The complete token stream and all lexical errors."""

    tokens: tuple[Token, ...]
    errors: tuple[LexicalError, ...]


@dataclass(frozen=True)
class SyntaxErrorInfo:
    """A recoverable syntax error and its one-based source position."""

    message: str
    line: int
    column: int


@dataclass(frozen=True)
class ParseResult:
    """A partial syntax tree and all syntax errors found while parsing."""

    program: Program
    errors: tuple[SyntaxErrorInfo, ...]
