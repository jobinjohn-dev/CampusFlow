"""Abstract syntax tree nodes for CampusFlow Phase 2."""

from dataclasses import dataclass


@dataclass(frozen=True)
class SourceLocation:
    line: int
    column: int


@dataclass(frozen=True)
class EventStatement:
    name: str
    date: str
    start_time: str
    end_time: str
    location: SourceLocation


@dataclass(frozen=True)
class ReserveStatement:
    resource: str
    event: str
    capacity: int
    location: SourceLocation


@dataclass(frozen=True)
class AssignStatement:
    equipment: str
    event: str
    location: SourceLocation


@dataclass(frozen=True)
class Condition:
    left: str
    operator: str
    right: int
    location: SourceLocation


@dataclass(frozen=True)
class ConditionalStatement:
    condition: Condition
    action: ReserveStatement
    location: SourceLocation


@dataclass(frozen=True)
class CancelStatement:
    event: str
    location: SourceLocation


Statement = (
    EventStatement
    | ReserveStatement
    | AssignStatement
    | ConditionalStatement
    | CancelStatement
)


@dataclass(frozen=True)
class Program:
    statements: tuple[Statement, ...]


def _location_text(location: SourceLocation) -> str:
    return f"{location.line}:{location.column}"


def _format_statement(statement: Statement, indent: int) -> list[str]:
    prefix = " " * indent
    field_prefix = " " * (indent + 2)

    if isinstance(statement, EventStatement):
        return [
            f"{prefix}EventStatement @ {_location_text(statement.location)}",
            f"{field_prefix}name: {statement.name}",
            f"{field_prefix}date: {statement.date}",
            f"{field_prefix}start_time: {statement.start_time}",
            f"{field_prefix}end_time: {statement.end_time}",
        ]
    if isinstance(statement, ReserveStatement):
        return [
            f"{prefix}ReserveStatement @ {_location_text(statement.location)}",
            f"{field_prefix}resource: {statement.resource}",
            f"{field_prefix}event: {statement.event}",
            f"{field_prefix}capacity: {statement.capacity}",
        ]
    if isinstance(statement, AssignStatement):
        return [
            f"{prefix}AssignStatement @ {_location_text(statement.location)}",
            f"{field_prefix}equipment: {statement.equipment}",
            f"{field_prefix}event: {statement.event}",
        ]
    if isinstance(statement, ConditionalStatement):
        condition = statement.condition
        lines = [
            f"{prefix}ConditionalStatement @ {_location_text(statement.location)}",
            f"{field_prefix}Condition @ {_location_text(condition.location)}",
            f"{field_prefix}  left: {condition.left}",
            f"{field_prefix}  operator: {condition.operator}",
            f"{field_prefix}  right: {condition.right}",
        ]
        lines.extend(_format_statement(statement.action, indent + 2))
        return lines
    if isinstance(statement, CancelStatement):
        return [
            f"{prefix}CancelStatement @ {_location_text(statement.location)}",
            f"{field_prefix}event: {statement.event}",
        ]
    raise TypeError(f"Unsupported AST node: {type(statement).__name__}")


def format_ast(program: Program) -> str:
    """Return a deterministic, indented representation of a CampusFlow AST."""
    if not program.statements:
        return "Program\n  <empty>"

    lines = ["Program"]
    for statement in program.statements:
        lines.extend(_format_statement(statement, 2))
    return "\n".join(lines)
