"""Stage-gated CampusFlow Phase 2 compiler front-end pipeline."""

from dataclasses import dataclass

from .ir import IRGenerator, Quadruple
from .lexer import Lexer
from .model import ParseResult, ScanResult
from .parser import Parser
from .semantic import SemanticAnalyzer, SemanticResult


@dataclass(frozen=True)
class CompilationResult:
    scan: ScanResult
    parse: ParseResult | None
    semantic: SemanticResult | None
    ir: tuple[Quadruple, ...]
    status: str


def compile_source(source: str) -> CompilationResult:
    scan = Lexer(source).scan()
    if scan.errors:
        return CompilationResult(scan, None, None, (), "lexical_error")

    parsed = Parser(scan.tokens).parse()
    if parsed.errors:
        return CompilationResult(scan, parsed, None, (), "syntax_error")

    semantic = SemanticAnalyzer().analyze(parsed.program)
    if semantic.errors:
        return CompilationResult(scan, parsed, semantic, (), "semantic_error")

    ir = IRGenerator().generate(parsed.program)
    return CompilationResult(scan, parsed, semantic, ir, "success")
