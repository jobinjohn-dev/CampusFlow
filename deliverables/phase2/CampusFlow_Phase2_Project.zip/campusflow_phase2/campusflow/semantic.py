"""Semantic checks and symbol construction for CampusFlow Phase 2."""

from dataclasses import dataclass

from .ast import (
    AssignStatement,
    CancelStatement,
    ConditionalStatement,
    EventStatement,
    Program,
    ReserveStatement,
    SourceLocation,
)
from .symbols import Symbol, SymbolTable


@dataclass(frozen=True)
class SemanticErrorInfo:
    message: str
    line: int
    column: int


@dataclass(frozen=True)
class SemanticResult:
    symbols: SymbolTable
    errors: tuple[SemanticErrorInfo, ...]


class SemanticAnalyzer:
    VALID_OPERATORS = {">", "<", ">=", "<=", "==", "!="}

    def analyze(self, program: Program) -> SemanticResult:
        symbols = SymbolTable()
        errors: list[SemanticErrorInfo] = []

        for statement in program.statements:
            if not isinstance(statement, EventStatement):
                continue
            symbol = Symbol(
                statement.name,
                "EVENT",
                "event",
                statement.location,
                (
                    ("date", statement.date),
                    ("time", f"{statement.start_time}..{statement.end_time}"),
                ),
            )
            if not symbols.insert(symbol):
                errors.append(
                    self._error(f"Duplicate event '{statement.name}'", statement.location)
                )
            if statement.end_time <= statement.start_time:
                errors.append(
                    self._error(
                        f"End time must be later than start time for event '{statement.name}'",
                        statement.location,
                    )
                )

        for statement in program.statements:
            if isinstance(statement, ReserveStatement):
                self._check_reserve(statement, symbols, errors)
            elif isinstance(statement, AssignStatement):
                self._check_event_reference(statement.event, statement.location, symbols, errors)
                symbols.insert(
                    Symbol(
                        statement.equipment,
                        "EQUIPMENT",
                        "equipment",
                        statement.location,
                        (),
                    )
                )
            elif isinstance(statement, CancelStatement):
                self._check_event_reference(statement.event, statement.location, symbols, errors)
            elif isinstance(statement, ConditionalStatement):
                if statement.condition.left != "capacity":
                    errors.append(
                        self._error(
                            "Condition identifier must be 'capacity'",
                            statement.condition.location,
                        )
                    )
                if statement.condition.operator not in self.VALID_OPERATORS:
                    errors.append(
                        self._error(
                            f"Unsupported condition operator '{statement.condition.operator}'",
                            statement.condition.location,
                        )
                    )
                self._check_reserve(statement.action, symbols, errors)

        errors.sort(key=lambda error: (error.line, error.column))
        return SemanticResult(symbols, tuple(errors))

    def _check_reserve(
        self,
        statement: ReserveStatement,
        symbols: SymbolTable,
        errors: list[SemanticErrorInfo],
    ) -> None:
        self._check_event_reference(statement.event, statement.location, symbols, errors)
        if statement.capacity <= 0:
            errors.append(
                self._error("Capacity must be greater than zero", statement.location)
            )
        symbols.insert(
            Symbol(statement.resource, "ROOM", "resource", statement.location, ())
        )

    def _check_event_reference(
        self,
        event: str,
        location: SourceLocation,
        symbols: SymbolTable,
        errors: list[SemanticErrorInfo],
    ) -> None:
        if symbols.lookup(event, "EVENT") is None:
            errors.append(self._error(f"Undeclared event '{event}'", location))

    @staticmethod
    def _error(message: str, location: SourceLocation) -> SemanticErrorInfo:
        return SemanticErrorInfo(message, location.line, location.column)
