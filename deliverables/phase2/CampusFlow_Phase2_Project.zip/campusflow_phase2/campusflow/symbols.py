"""Global symbol table for CampusFlow Phase 2."""

from dataclasses import dataclass

from .ast import SourceLocation


@dataclass(frozen=True)
class Symbol:
    name: str
    kind: str
    data_type: str
    location: SourceLocation
    attributes: tuple[tuple[str, str], ...]


class SymbolTable:
    """Insertion-ordered symbols in the single CampusFlow global scope."""

    def __init__(self):
        self._symbols: list[Symbol] = []

    @property
    def symbols(self) -> tuple[Symbol, ...]:
        return tuple(self._symbols)

    def insert(self, symbol: Symbol) -> bool:
        existing = self.lookup(symbol.name, symbol.kind)
        if existing is not None:
            return symbol.kind != "EVENT"
        self._symbols.append(symbol)
        return True

    def lookup(self, name: str, kind: str | None = None) -> Symbol | None:
        for symbol in self._symbols:
            if symbol.name == name and (kind is None or symbol.kind == kind):
                return symbol
        return None


def format_symbol_table(table: SymbolTable) -> str:
    lines = [
        "KIND       NAME                 TYPE         DECLARED   ATTRIBUTES",
        "---------- -------------------- ------------ ---------- ------------------------------",
    ]
    for symbol in table.symbols:
        location = f"{symbol.location.line}:{symbol.location.column}"
        attributes = ", ".join(f"{key}={value}" for key, value in symbol.attributes) or "-"
        lines.append(
            f"{symbol.kind:<10} {symbol.name:<20} {symbol.data_type:<12} "
            f"{location:<10} {attributes}"
        )
    if not table.symbols:
        lines.append("<empty>")
    return "\n".join(lines)
