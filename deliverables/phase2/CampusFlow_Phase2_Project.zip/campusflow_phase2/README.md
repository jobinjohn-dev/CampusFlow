# CampusFlow DSL — Phase 2 Core Implementation

CampusFlow is a small domain-specific language for describing campus events,
room reservations, equipment assignments, conditional reservations, and event
cancellations. This Phase 2 package implements a working compiler front end
using only the Python standard library.

## Implemented modules

- Lexical analyzer with positioned tokens and recoverable errors
- Recursive-descent parser with statement-boundary recovery
- Abstract syntax tree (AST) construction and text visualization
- Global symbol table for events, rooms, and equipment
- Semantic checks for declarations, references, time order, capacity, and conditions
- Quadruple intermediate-code generation
- Stage-gated compiler driver and command-line demonstration
- Automated unit and integration tests

## Requirements

- Python 3.10 or newer
- No third-party packages

## Run the complete demonstration

From this folder:

```bash
python3 run.py examples/phase2_valid.cflow
```

Windows users can use:

```powershell
py run.py examples\phase2_valid.cflow
```

The command displays the token stream, AST, symbol table, and quadruple IR.

## Display one compiler stage

```bash
python3 run.py --stage tokens examples/phase2_valid.cflow
python3 run.py --stage ast examples/phase2_valid.cflow
python3 run.py --stage symbols examples/phase2_valid.cflow
python3 run.py --stage ir examples/phase2_valid.cflow
```

`--stage all` is the default.

## Demonstrate error handling

```bash
python3 run.py examples/invalid.cflow
python3 run.py examples/phase2_syntax_errors.cflow
python3 run.py examples/phase2_semantic_errors.cflow
```

Exit status is `0` for success, `1` for lexical errors, `2` for syntax errors,
and `3` for semantic errors. A failed stage prevents unsafe later stages.

## Run the tests

```bash
python3 -m unittest discover -s tests -v
```

## Language examples

```text
EVENT TechFest ON 2026-11-20 AT 09:00 TO 17:00;
RESERVE Auditorium_A FOR TechFest CAPACITY 150;
ASSIGN Projector TO TechFest;
IF capacity >= 100 THEN RESERVE SeminarHall FOR TechFest CAPACITY 120;
CANCEL TechFest;
```

Keywords are case-insensitive. Identifiers retain their original spelling.
Every statement ends in a semicolon.
