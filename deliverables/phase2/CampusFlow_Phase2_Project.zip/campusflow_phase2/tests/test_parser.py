import unittest

from campusflow.ast import (
    AssignStatement,
    CancelStatement,
    ConditionalStatement,
    EventStatement,
    ReserveStatement,
)
from campusflow.lexer import Lexer
from campusflow.parser import Parser


def parse(source):
    scan = Lexer(source).scan()
    if scan.errors:
        raise AssertionError(f"unexpected lexical errors: {scan.errors}")
    return Parser(scan.tokens).parse()


class ParserTests(unittest.TestCase):
    def test_parses_every_statement_type_with_values_and_locations(self):
        result = parse(
            "\n".join(
                [
                    "EVENT TechFest ON 2026-10-15 AT 10:00 TO 12:00;",
                    "RESERVE Auditorium_A FOR TechFest CAPACITY 150;",
                    "ASSIGN Projector TO TechFest;",
                    "IF capacity >= 100 THEN RESERVE Seminar_Hall FOR TechFest CAPACITY 120;",
                    "CANCEL TechFest;",
                ]
            )
        )

        self.assertEqual(result.errors, ())
        self.assertEqual(len(result.program.statements), 5)
        event, reserve, assign, conditional, cancel = result.program.statements
        self.assertIsInstance(event, EventStatement)
        self.assertEqual(
            (event.name, event.date, event.start_time, event.end_time),
            ("TechFest", "2026-10-15", "10:00", "12:00"),
        )
        self.assertEqual((event.location.line, event.location.column), (1, 1))
        self.assertIsInstance(reserve, ReserveStatement)
        self.assertEqual((reserve.resource, reserve.event, reserve.capacity), ("Auditorium_A", "TechFest", 150))
        self.assertIsInstance(assign, AssignStatement)
        self.assertEqual((assign.equipment, assign.event), ("Projector", "TechFest"))
        self.assertIsInstance(conditional, ConditionalStatement)
        self.assertEqual(
            (conditional.condition.left, conditional.condition.operator, conditional.condition.right),
            ("capacity", ">=", 100),
        )
        self.assertEqual(conditional.action.resource, "Seminar_Hall")
        self.assertIsInstance(cancel, CancelStatement)
        self.assertEqual(cancel.event, "TechFest")

    def test_keywords_are_case_insensitive_but_condition_identifier_is_preserved(self):
        result = parse(
            "event Demo on 2026-11-01 at 09:00 to 10:00; "
            "if Capacity >= 1 then reserve Hall for Demo capacity 1;"
        )

        self.assertEqual(result.errors, ())
        conditional = result.program.statements[1]
        self.assertEqual(conditional.condition.left, "Capacity")

    def test_empty_program_is_valid(self):
        result = parse("")

        self.assertEqual(result.program.statements, ())
        self.assertEqual(result.errors, ())

    def test_reports_missing_semicolon(self):
        result = parse("CANCEL Demo")

        self.assertEqual(len(result.errors), 1)
        self.assertIn("Expected ';'", result.errors[0].message)
        self.assertEqual((result.errors[0].line, result.errors[0].column), (1, 12))

    def test_reports_missing_required_keyword(self):
        result = parse("EVENT Demo 2026-11-01 AT 09:00 TO 10:00;")

        self.assertGreaterEqual(len(result.errors), 1)
        self.assertIn("Expected keyword ON", result.errors[0].message)

    def test_reports_incomplete_statement_at_eof(self):
        result = parse("RESERVE Hall FOR")

        self.assertEqual(len(result.errors), 1)
        self.assertIn("Expected event identifier", result.errors[0].message)

    def test_unsupported_statement_start_is_a_positioned_error(self):
        result = parse("UNKNOWN Value;")

        self.assertEqual(len(result.errors), 1)
        self.assertIn("Expected a statement keyword", result.errors[0].message)
        self.assertEqual((result.errors[0].line, result.errors[0].column), (1, 1))

    def test_recovers_at_semicolon_and_keeps_following_statement(self):
        result = parse("EVENT Broken ON ; CANCEL Valid;")

        self.assertEqual(len(result.errors), 1)
        self.assertIn("Expected date", result.errors[0].message)
        self.assertEqual(len(result.program.statements), 1)
        self.assertIsInstance(result.program.statements[0], CancelStatement)
        self.assertEqual(result.program.statements[0].event, "Valid")


if __name__ == "__main__":
    unittest.main()
