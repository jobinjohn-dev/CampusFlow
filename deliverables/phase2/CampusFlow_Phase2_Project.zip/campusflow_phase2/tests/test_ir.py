import unittest

from campusflow.ir import IRGenerator, Quadruple, format_ir
from campusflow.lexer import Lexer
from campusflow.parser import Parser


def parsed_program(source):
    scan = Lexer(source).scan()
    parsed = Parser(scan.tokens).parse()
    if scan.errors or parsed.errors:
        raise AssertionError((scan.errors, parsed.errors))
    return parsed.program


class IRTests(unittest.TestCase):
    def test_generates_exact_quadruples_for_every_statement_type(self):
        program = parsed_program(
            "EVENT TechFest ON 2026-10-15 AT 10:00 TO 12:00;\n"
            "RESERVE Hall_A FOR TechFest CAPACITY 150;\n"
            "ASSIGN Projector TO TechFest;\n"
            "IF capacity >= 100 THEN RESERVE Hall_B FOR TechFest CAPACITY 120;\n"
            "CANCEL TechFest;"
        )

        code = IRGenerator().generate(program)

        self.assertEqual(
            code,
            (
                Quadruple("EVENT", "2026-10-15", "10:00..12:00", "TechFest"),
                Quadruple("RESERVE", "Hall_A", "150", "TechFest"),
                Quadruple("ASSIGN", "Projector", "-", "TechFest"),
                Quadruple("IF_FALSE", "capacity >= 100", "-", "L1"),
                Quadruple("RESERVE", "Hall_B", "120", "TechFest"),
                Quadruple("LABEL", "-", "-", "L1"),
                Quadruple("CANCEL", "TechFest", "-", "-"),
            ),
        )

    def test_conditional_labels_are_deterministic(self):
        program = parsed_program(
            "EVENT Demo ON 2026-11-01 AT 09:00 TO 10:00;\n"
            "IF capacity > 1 THEN RESERVE A FOR Demo CAPACITY 2;\n"
            "IF capacity < 9 THEN RESERVE B FOR Demo CAPACITY 8;"
        )

        code = IRGenerator().generate(program)

        self.assertEqual(
            [item.result for item in code if item.operation == "IF_FALSE"],
            ["L1", "L2"],
        )

    def test_formats_ir_as_indexed_table(self):
        code = (
            Quadruple("EVENT", "2026-10-15", "10:00..12:00", "TechFest"),
            Quadruple("CANCEL", "TechFest", "-", "-"),
        )

        self.assertEqual(
            format_ir(code),
            "\n".join(
                [
                    "#    OP           ARG1                 ARG2                 RESULT",
                    "---- ------------ -------------------- -------------------- --------------------",
                    "1    EVENT        2026-10-15           10:00..12:00         TechFest",
                    "2    CANCEL       TechFest             -                    -",
                ]
            ),
        )

    def test_empty_program_generates_empty_ir(self):
        self.assertEqual(IRGenerator().generate(parsed_program("")), ())
        self.assertIn("<empty>", format_ir(()))


if __name__ == "__main__":
    unittest.main()
