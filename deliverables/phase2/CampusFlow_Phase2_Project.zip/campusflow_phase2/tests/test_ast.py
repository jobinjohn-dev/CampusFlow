import unittest
from dataclasses import FrozenInstanceError

from campusflow.ast import (
    AssignStatement,
    CancelStatement,
    Condition,
    ConditionalStatement,
    EventStatement,
    Program,
    ReserveStatement,
    SourceLocation,
    format_ast,
)


class AstTests(unittest.TestCase):
    def test_formats_complete_program_tree(self):
        program = Program(
            (
                EventStatement(
                    "TechFest", "2026-10-15", "10:00", "12:00", SourceLocation(1, 1)
                ),
                ReserveStatement("Auditorium_A", "TechFest", 150, SourceLocation(2, 1)),
                AssignStatement("Projector", "TechFest", SourceLocation(3, 1)),
                ConditionalStatement(
                    Condition("capacity", ">=", 100, SourceLocation(4, 4)),
                    ReserveStatement("Seminar_Hall", "TechFest", 120, SourceLocation(4, 25)),
                    SourceLocation(4, 1),
                ),
                CancelStatement("TechFest", SourceLocation(5, 1)),
            )
        )

        self.assertEqual(
            format_ast(program),
            "\n".join(
                [
                    "Program",
                    "  EventStatement @ 1:1",
                    "    name: TechFest",
                    "    date: 2026-10-15",
                    "    start_time: 10:00",
                    "    end_time: 12:00",
                    "  ReserveStatement @ 2:1",
                    "    resource: Auditorium_A",
                    "    event: TechFest",
                    "    capacity: 150",
                    "  AssignStatement @ 3:1",
                    "    equipment: Projector",
                    "    event: TechFest",
                    "  ConditionalStatement @ 4:1",
                    "    Condition @ 4:4",
                    "      left: capacity",
                    "      operator: >=",
                    "      right: 100",
                    "    ReserveStatement @ 4:25",
                    "      resource: Seminar_Hall",
                    "      event: TechFest",
                    "      capacity: 120",
                    "  CancelStatement @ 5:1",
                    "    event: TechFest",
                ]
            ),
        )

    def test_ast_nodes_are_immutable(self):
        node = CancelStatement("TechFest", SourceLocation(1, 1))

        with self.assertRaises(FrozenInstanceError):
            node.event = "Changed"

    def test_empty_program_formats_deterministically(self):
        self.assertEqual(format_ast(Program(())), "Program\n  <empty>")


if __name__ == "__main__":
    unittest.main()
