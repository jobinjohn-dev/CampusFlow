import subprocess
import sys
import tempfile
import unittest
from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parents[1]
RUNNER = PROJECT_ROOT / "run.py"


VALID_SOURCE = """\
EVENT Demo ON 2026-10-10 AT 09:00 TO 11:00;
RESERVE MainHall FOR Demo CAPACITY 100;
ASSIGN Projector TO Demo;
IF capacity >= 50 THEN RESERVE Lab FOR Demo CAPACITY 60;
CANCEL Demo;
"""


class Phase2CliTests(unittest.TestCase):
    def run_source(self, source, *arguments):
        with tempfile.TemporaryDirectory() as directory:
            source_path = Path(directory) / "input.cflow"
            source_path.write_text(source, encoding="utf-8")
            return subprocess.run(
                [sys.executable, str(RUNNER), *arguments, str(source_path)],
                cwd=PROJECT_ROOT,
                capture_output=True,
                text=True,
                check=False,
            )

    def test_default_stage_displays_all_successful_outputs(self):
        completed = self.run_source(VALID_SOURCE)

        self.assertEqual(completed.returncode, 0)
        self.assertIn("TOKENS", completed.stdout)
        self.assertIn("ABSTRACT SYNTAX TREE", completed.stdout)
        self.assertIn("SYMBOL TABLE", completed.stdout)
        self.assertIn("INTERMEDIATE CODE", completed.stdout)
        self.assertIn("Compilation completed successfully.", completed.stdout)

    def test_each_stage_limits_the_displayed_output(self):
        expectations = {
            "tokens": ("TOKENS", "ABSTRACT SYNTAX TREE"),
            "ast": ("ABSTRACT SYNTAX TREE", "SYMBOL TABLE"),
            "symbols": ("SYMBOL TABLE", "INTERMEDIATE CODE"),
            "ir": ("INTERMEDIATE CODE", "SYMBOL TABLE"),
        }
        for stage, (included, excluded) in expectations.items():
            with self.subTest(stage=stage):
                completed = self.run_source(VALID_SOURCE, "--stage", stage)
                self.assertEqual(completed.returncode, 0)
                self.assertIn(included, completed.stdout)
                self.assertNotIn(excluded, completed.stdout)

    def test_lexical_error_stops_pipeline_with_exit_one(self):
        completed = self.run_source("EVENT @Demo;")

        self.assertEqual(completed.returncode, 1)
        self.assertIn("LEXICAL ERRORS", completed.stdout)
        self.assertNotIn("ABSTRACT SYNTAX TREE", completed.stdout)

    def test_syntax_error_stops_pipeline_with_exit_two(self):
        completed = self.run_source("EVENT Demo ON;")

        self.assertEqual(completed.returncode, 2)
        self.assertIn("SYNTAX ERRORS", completed.stdout)
        self.assertNotIn("SYMBOL TABLE", completed.stdout)

    def test_semantic_error_stops_before_ir_with_exit_three(self):
        completed = self.run_source("CANCEL Missing;")

        self.assertEqual(completed.returncode, 3)
        self.assertIn("SEMANTIC ERRORS", completed.stdout)
        self.assertNotIn("INTERMEDIATE CODE", completed.stdout)

    def test_empty_file_is_a_valid_empty_program(self):
        completed = self.run_source("")

        self.assertEqual(completed.returncode, 0)
        self.assertIn("<empty>", completed.stdout)


if __name__ == "__main__":
    unittest.main()
