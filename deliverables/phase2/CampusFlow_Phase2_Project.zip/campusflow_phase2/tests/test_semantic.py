import unittest

from campusflow.ast import (
    Condition,
    ConditionalStatement,
    EventStatement,
    Program,
    ReserveStatement,
    SourceLocation,
)
from campusflow.lexer import Lexer
from campusflow.parser import Parser
from campusflow.semantic import SemanticAnalyzer
from campusflow.symbols import Symbol, SymbolTable, format_symbol_table


def program_from(source):
    scan = Lexer(source).scan()
    if scan.errors:
        raise AssertionError(scan.errors)
    parsed = Parser(scan.tokens).parse()
    if parsed.errors:
        raise AssertionError(parsed.errors)
    return parsed.program


class SymbolTableTests(unittest.TestCase):
    def test_inserts_looks_up_and_formats_symbols_in_source_order(self):
        table = SymbolTable()
        self.assertTrue(
            table.insert(
                Symbol(
                    "TechFest",
                    "EVENT",
                    "event",
                    SourceLocation(1, 1),
                    (("date", "2026-10-15"), ("time", "10:00..12:00")),
                )
            )
        )
        self.assertTrue(
            table.insert(Symbol("Hall_A", "ROOM", "resource", SourceLocation(2, 1), ()))
        )
        self.assertTrue(
            table.insert(
                Symbol("Projector", "EQUIPMENT", "equipment", SourceLocation(3, 1), ())
            )
        )

        self.assertEqual(table.lookup("TechFest", "EVENT").data_type, "event")
        self.assertIsNone(table.lookup("Missing"))
        self.assertEqual(
            format_symbol_table(table),
            "\n".join(
                [
                    "KIND       NAME                 TYPE         DECLARED   ATTRIBUTES",
                    "---------- -------------------- ------------ ---------- ------------------------------",
                    "EVENT      TechFest             event        1:1        date=2026-10-15, time=10:00..12:00",
                    "ROOM       Hall_A               resource     2:1        -",
                    "EQUIPMENT  Projector            equipment    3:1        -",
                ]
            ),
        )

    def test_reusing_room_and_equipment_is_allowed_without_duplicate_rows(self):
        table = SymbolTable()
        room = Symbol("Hall", "ROOM", "resource", SourceLocation(1, 1), ())
        equipment = Symbol("Projector", "EQUIPMENT", "equipment", SourceLocation(2, 1), ())

        self.assertTrue(table.insert(room))
        self.assertTrue(table.insert(room))
        self.assertTrue(table.insert(equipment))
        self.assertTrue(table.insert(equipment))
        self.assertEqual(len(table.symbols), 2)


class SemanticTests(unittest.TestCase):
    def test_builds_symbols_for_valid_program(self):
        program = program_from(
            "EVENT TechFest ON 2026-10-15 AT 10:00 TO 12:00;\n"
            "RESERVE Hall_A FOR TechFest CAPACITY 150;\n"
            "ASSIGN Projector TO TechFest;"
        )

        result = SemanticAnalyzer().analyze(program)

        self.assertEqual(result.errors, ())
        self.assertIsNotNone(result.symbols.lookup("TechFest", "EVENT"))
        self.assertIsNotNone(result.symbols.lookup("Hall_A", "ROOM"))
        self.assertIsNotNone(result.symbols.lookup("Projector", "EQUIPMENT"))

    def test_reports_duplicate_event_declaration(self):
        program = program_from(
            "EVENT Demo ON 2026-11-01 AT 09:00 TO 10:00;\n"
            "EVENT Demo ON 2026-11-02 AT 11:00 TO 12:00;"
        )

        result = SemanticAnalyzer().analyze(program)

        self.assertEqual(len(result.errors), 1)
        self.assertIn("Duplicate event 'Demo'", result.errors[0].message)
        self.assertEqual((result.errors[0].line, result.errors[0].column), (2, 1))

    def test_reports_event_end_time_not_after_start(self):
        program = program_from("EVENT Demo ON 2026-11-01 AT 10:00 TO 09:00;")

        result = SemanticAnalyzer().analyze(program)

        self.assertEqual(len(result.errors), 1)
        self.assertIn("End time must be later", result.errors[0].message)

    def test_reports_undeclared_event_references_for_all_statement_types(self):
        program = program_from(
            "RESERVE Hall FOR Missing CAPACITY 10;\n"
            "ASSIGN Projector TO Missing;\n"
            "CANCEL Missing;"
        )

        result = SemanticAnalyzer().analyze(program)

        self.assertEqual(len(result.errors), 3)
        self.assertTrue(all("Undeclared event 'Missing'" in error.message for error in result.errors))
        self.assertEqual([error.line for error in result.errors], [1, 2, 3])

    def test_reports_nonpositive_capacity(self):
        program = Program(
            (
                EventStatement("Demo", "2026-11-01", "09:00", "10:00", SourceLocation(1, 1)),
                ReserveStatement("Hall", "Demo", -1, SourceLocation(2, 1)),
            )
        )

        result = SemanticAnalyzer().analyze(program)

        self.assertEqual(len(result.errors), 1)
        self.assertIn("Capacity must be greater than zero", result.errors[0].message)

    def test_reports_condition_identifier_case_and_invalid_operator(self):
        program = Program(
            (
                EventStatement("Demo", "2026-11-01", "09:00", "10:00", SourceLocation(1, 1)),
                ConditionalStatement(
                    Condition("Capacity", "+", 1, SourceLocation(2, 4)),
                    ReserveStatement("Hall", "Demo", 1, SourceLocation(2, 20)),
                    SourceLocation(2, 1),
                ),
            )
        )

        result = SemanticAnalyzer().analyze(program)

        self.assertEqual(len(result.errors), 2)
        self.assertIn("must be 'capacity'", result.errors[0].message)
        self.assertIn("Unsupported condition operator '+'", result.errors[1].message)

    def test_collects_multiple_errors_in_source_order(self):
        program = program_from(
            "EVENT Demo ON 2026-11-01 AT 10:00 TO 09:00;\n"
            "EVENT Demo ON 2026-11-02 AT 11:00 TO 12:00;\n"
            "RESERVE Hall FOR Missing CAPACITY 0;"
        )

        result = SemanticAnalyzer().analyze(program)

        self.assertEqual([error.line for error in result.errors], [1, 2, 3, 3])


if __name__ == "__main__":
    unittest.main()
