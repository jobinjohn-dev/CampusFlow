import unittest

from campusflow.compiler import compile_source


class CompilerPipelineTests(unittest.TestCase):
    def test_lexical_errors_block_all_later_stages(self):
        result = compile_source("RESERVE @Hall;")

        self.assertEqual(result.status, "lexical_error")
        self.assertTrue(result.scan.errors)
        self.assertIsNone(result.parse)
        self.assertIsNone(result.semantic)
        self.assertEqual(result.ir, ())

    def test_syntax_errors_block_semantics_and_ir(self):
        result = compile_source("CANCEL Demo")

        self.assertEqual(result.status, "syntax_error")
        self.assertTrue(result.parse.errors)
        self.assertIsNone(result.semantic)
        self.assertEqual(result.ir, ())

    def test_semantic_errors_block_ir(self):
        result = compile_source("CANCEL Missing;")

        self.assertEqual(result.status, "semantic_error")
        self.assertTrue(result.semantic.errors)
        self.assertEqual(result.ir, ())

    def test_valid_program_completes_all_stages(self):
        result = compile_source(
            "EVENT Demo ON 2026-11-01 AT 09:00 TO 10:00; CANCEL Demo;"
        )

        self.assertEqual(result.status, "success")
        self.assertEqual(result.scan.errors, ())
        self.assertEqual(result.parse.errors, ())
        self.assertEqual(result.semantic.errors, ())
        self.assertEqual(len(result.ir), 2)

    def test_empty_file_completes_with_empty_results(self):
        result = compile_source("")

        self.assertEqual(result.status, "success")
        self.assertEqual(result.parse.program.statements, ())
        self.assertEqual(result.semantic.symbols.symbols, ())
        self.assertEqual(result.ir, ())


if __name__ == "__main__":
    unittest.main()
