"""CampusFlow compiler public interfaces."""

from .ast_nodes import (
    AssignStatement,
    CancelStatement,
    CapacityExpression,
    ComparisonExpression,
    EventStatement,
    IfStatement,
    NumberLiteral,
    Program,
    ReserveStatement,
    format_ast,
)
from .lexer import Lexer
from .ir import IRGenerator, IRProgram, Instruction, format_ir
from .interpreter import (
    ExecutionResult,
    Interpreter,
    RuntimeAssignment,
    RuntimeDiagnostic,
    RuntimeEvent,
    RuntimeReservation,
    RuntimeState,
    format_runtime,
)
from .model import LexicalError, ScanResult, Token
from .metrics import BenchmarkResult, benchmark_ir, format_benchmark
from .optimizer import (
    IROptimizer,
    OptimizationResult,
    OptimizationStats,
    OptimizerDiagnostic,
    format_optimization,
)
from .parser import ParseResult, Parser, SyntaxDiagnostic
from .pipeline import PipelineResult, compile_source
from .semantic import SemanticAnalyzer, SemanticDiagnostic, SemanticResult
from .symbols import (
    AssignmentSymbol,
    EventSymbol,
    ReservationSymbol,
    SymbolTable,
    intervals_overlap,
)

__all__ = [
    "AssignStatement",
    "AssignmentSymbol",
    "BenchmarkResult",
    "CancelStatement",
    "CapacityExpression",
    "ComparisonExpression",
    "EventStatement",
    "EventSymbol",
    "ExecutionResult",
    "IfStatement",
    "IRGenerator",
    "IRProgram",
    "Instruction",
    "Interpreter",
    "IROptimizer",
    "Lexer",
    "LexicalError",
    "NumberLiteral",
    "OptimizationResult",
    "OptimizationStats",
    "OptimizerDiagnostic",
    "ParseResult",
    "Parser",
    "PipelineResult",
    "Program",
    "ReserveStatement",
    "ReservationSymbol",
    "RuntimeAssignment",
    "RuntimeDiagnostic",
    "RuntimeEvent",
    "RuntimeReservation",
    "RuntimeState",
    "ScanResult",
    "SemanticAnalyzer",
    "SemanticDiagnostic",
    "SemanticResult",
    "SymbolTable",
    "Token",
    "SyntaxDiagnostic",
    "benchmark_ir",
    "format_ast",
    "format_benchmark",
    "format_ir",
    "format_optimization",
    "format_runtime",
    "intervals_overlap",
    "compile_source",
]
